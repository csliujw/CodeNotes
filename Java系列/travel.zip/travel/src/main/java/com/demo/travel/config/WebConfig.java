package com.xw.travel.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private LoginInterceptor loginInterceptor = new LoginInterceptor();

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor)
                .addPathPatterns("/travel/**") // 拦截所有请求
                .excludePathPatterns("/travel/login", "/travel/logout"); // 排除登录和登出接口
    }
}

class LoginInterceptor implements HandlerInterceptor {


    // 此处校验 token 的正确性/判断用户是否登录。
    public boolean validateToken(String token) {
        return true;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 拿到 token openid
        String token = request.getHeader("openid"); // 从请求头中获取token
        if (token != null && validateToken(token)) {
            // 检验 openid 的合法性
            // 合法则返回 true
            return true;
        }

        System.out.println("没有 openid 或不合法");
        // 如果没有有效的token，或者token验证失败，返回false，表示拦截请求
        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.getWriter().write("Unauthorized");
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        // 请求处理之后，视图渲染之前的逻辑
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // 请求处理完成后的逻辑
    }
}