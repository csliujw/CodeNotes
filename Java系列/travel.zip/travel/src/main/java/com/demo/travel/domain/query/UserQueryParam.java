package com.demo.travel.domain.query;

// 接收前端发送的查询参数
public class UserQueryParam {
}
