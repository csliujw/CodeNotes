package com.demo.travel.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.travel.domain.VillagesDO;

public interface VillagesMapper extends BaseMapper<VillagesDO> {
}
