package com.demo.travel.constant;

/**
 * @author ljw
 * @date 2024/11/17 0:13
 */
public class Constants {

    public final static int OK_CODE = 200;
    public final static int FAIL_CODE = 500;
    public final static int FAIL_MESSAGE_NOT_FOUND = 404;
    public final static int OTHER_FAIL_CODE = 333;
    public final static String OK_MSG = "请求成功";
    public final static String FAIL_MSG = "请求失败";
    public final static int STATUS_0 = 0;
    public final static int STATUS_1 = 1;
    public static final String NOT_FOUND_MSG = "未找到请求资源";
}
