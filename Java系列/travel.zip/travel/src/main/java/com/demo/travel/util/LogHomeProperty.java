package com.demo.travel.util;

import ch.qos.logback.core.PropertyDefinerBase;

public class LogHomeProperty extends PropertyDefinerBase {
    /**
     * @description 目录结构 根据工作的当前目录来创建
     * @author liujiawei
     * @date 2024/11/16 23:43
     * @params
     * @return
     */
    private static final String LOG_HOME =System.getProperty("user.dir") +"/logs";

    @Override
    public String getPropertyValue() {
        return LOG_HOME;
    }
}
