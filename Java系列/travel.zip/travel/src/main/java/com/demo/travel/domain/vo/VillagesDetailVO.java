package com.demo.travel.domain.vo;

import com.demo.travel.domain.VillagesDO;

public class VillagesDetailVO extends VillagesDO {
}
