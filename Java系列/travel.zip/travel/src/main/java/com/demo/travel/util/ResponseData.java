package com.demo.travel.util;

import com.demo.travel.constant.Constants;
import lombok.Data;

import java.io.Serializable;

/**
 * @author ljw
 * @date 2024/11/17 0:13
 *
 * <p>
 *   通用的响应体
 * </p>
 */
@Data
public class ResponseData<T> implements Serializable {
    private static final long serialVersionUID = 1L;
    private int code;
    private String message;

    // 分页查询 (可能需要用到的分页数据)
    private Long total = 0L; // 总数据量
    private Long page = 1L; // 当前是第几页
    private Long limit = 10L; // 每页的数量

    private T data;

    /**
     * 目前考虑
     */
    public ResponseData() {}

    public ResponseData(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public ResponseData(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseData{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }

    // 成功响应
    public static ResponseData<Void> ok() {
        return new ResponseData<>(Constants.OK_CODE, Constants.OK_MSG);
    }

    public static <T> ResponseData<T> ok(T data) {
        return new ResponseData<>(Constants.OK_CODE, Constants.OK_MSG, data);
    }

    public static ResponseData<Void> ok(String msg) {
        return new ResponseData<>(Constants.OK_CODE, msg);
    }

    public static <T> ResponseData<T> error(String message) {
        return new ResponseData<>(Constants.FAIL_CODE, message);
    }

    // 未找到资源响应
    public static <T> ResponseData<T> notFound() {
        return new ResponseData<>(Constants.FAIL_MESSAGE_NOT_FOUND, Constants.NOT_FOUND_MSG);
    }

    public static <T> ResponseData<T> notFound(String message) {
        return new ResponseData<>(Constants.FAIL_MESSAGE_NOT_FOUND, message);
    }

    // 其他自定义响应
    public static <T> ResponseData<T> custom(int code, String message, T data) {
        return new ResponseData<>(code, message, data);
    }
}
