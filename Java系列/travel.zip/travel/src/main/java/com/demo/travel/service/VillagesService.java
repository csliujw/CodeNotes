package com.demo.travel.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.demo.travel.domain.VillagesDO;
import com.demo.travel.domain.vo.VillagesDetailVO;
import com.demo.travel.mapper.VillagesMapper;
import com.demo.travel.util.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 我这里 POJO 划分的比较细。分了
 * - 专门用来接受前端参数的 xxQueryParam
 * - 专门用来返回给前端的 xxVO
 * - 和数据库一一对应的 xxDO
 * 目前项目比较简单，可以只分 xxQueryParam 和 xxVO，不使用 xxDO
 */
@Service
public class VillagesService {

    @Autowired
    private VillagesMapper villagesMapper;
    public ResponseData<List<VillagesDetailVO>> querySelective(String name, String desc, Integer page, Integer limit) {
        LambdaQueryWrapper<VillagesDO> queryWrapper = new LambdaQueryWrapper<>();

        queryWrapper.eq(VillagesDO::getDeleted,0);

        if( !"".equals(name) ){
            queryWrapper.like(VillagesDO::getName, name);
        }
        if ( !"".equals(desc) ){
            queryWrapper.like(VillagesDO::getDescription, desc);
        }

        IPage<VillagesDO> result = villagesMapper.selectPage(new Page<>(page, limit), queryWrapper);

        List<VillagesDetailVO> voList = result.getRecords().stream()
                .map(this::convertToVillagesDetailVO)
                .collect(Collectors.toList());

        return ResponseData.ok(voList);
    }

    // DO 转 VO
    private VillagesDetailVO convertToVillagesDetailVO(VillagesDO doObj) {
        VillagesDetailVO vo = new VillagesDetailVO();
        vo.setId(doObj.getId());
        vo.setName(doObj.getName());
        vo.setDescription(doObj.getDescription());
        // 其他属性的转换
        return vo;
    }

    public boolean insertVillages(VillagesDetailVO villagesDetailVO) {
        return villagesMapper.insert(villagesDetailVO)>0;
    }
}
