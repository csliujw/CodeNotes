package com.demo.travel.controller;

import com.demo.travel.util.ResponseData;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import javax.annotation.Resource;
import java.util.Map;

@RestController
// 404 notfound 返回json数据
public class CustomErrorController implements ErrorController {

       @Resource
       private ErrorAttributes errorAttributes;

       @RequestMapping("/error")
       public ResponseData<Object> handleError(WebRequest webRequest) {
           Map<String, Object> errorAttributesMap = errorAttributes.getErrorAttributes(webRequest, ErrorAttributeOptions.of(ErrorAttributeOptions.Include.MESSAGE));
           HttpStatus status = getStatus(webRequest);

           if (status == HttpStatus.NOT_FOUND) {
               return ResponseData.notFound();
           }else{
               return ResponseData.error("error");
           }
       }

       private HttpStatus getStatus(WebRequest request) {
           Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code", WebRequest.SCOPE_REQUEST);
           if (statusCode != null) {
               try {
                   return HttpStatus.valueOf(statusCode);
               } catch (Exception ex) {
               }
           }
           return HttpStatus.INTERNAL_SERVER_ERROR;
       }
   }
   