package com.demo.travel.controller.villages;

import com.demo.travel.domain.vo.VillagesDetailVO;
import com.demo.travel.exception.TravelException;
import com.demo.travel.service.VillagesService;
import com.demo.travel.util.ResponseData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Validated
@RequestMapping("/travel/villages")
@Slf4j
@SuppressWarnings("all")
public class VillagesController {

    @Autowired
    private VillagesService villagesService;
    @RequestMapping("/list")
    public ResponseData<List<VillagesDetailVO>> list(@RequestParam(defaultValue = "") String name,
                                                     @RequestParam(defaultValue = "") String desc,
                                                     @RequestParam(defaultValue = "1") Integer page,
                                                     @RequestParam(defaultValue = "20") Integer limit){
        return villagesService.querySelective(name, desc, page, limit);
    }

    @PostMapping("/insert")
    public ResponseData insert(@RequestBody VillagesDetailVO villagesDetailVO){
        return villagesService.insertVillages(villagesDetailVO) ? ResponseData.ok(): ResponseData.error("插入失败");
    }
    // 全局异常捕捉测试
    @GetMapping("/error")
    public ResponseData error(){
        throw new TravelException();
    }

}
