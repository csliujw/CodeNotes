- query
  - 用于接受前端查询参数的 POJO
- vo
  - 用户前端展示的数据对象，比如，前端需要展示的订单列表信息，那么这个订单列表就是 vo
- xxxDO
  - 直接映射数据库表的 Java 对象。比如，有一个用户表，则对应的 POJO 命名为 UserDO

POJO 中如果有公共字段，可以抽取成一个基类( BaseEntity )，其他类继承这个基类

如果POJO分成 DO VO 的话，那么是需要做 DO 和 VO 的转换的。目前项目比较简单，可以只分 query 和 VO