package com.demo.travel.exception;

import lombok.Data;

@Data
public class TravelException extends RuntimeException {
    protected Integer errorCode;
    protected String errorMsg;

    public TravelException(){}

    public TravelException(Integer errorCode, String errorMsg) {
        super(errorMsg);
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    /**
     * 服务器错误
     * @param errorMsg
     */
    public TravelException(String errorMsg) {
        super(errorMsg);
        this.errorCode = 500;
        this.errorMsg = errorMsg;
    }
}
