package com.demo.travel.domain;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

@EqualsAndHashCode(callSuper = false)
@TableName("villages")
@Data
public class VillagesDO extends BaseEntity{

    private Integer rating;

    private String imageUrl;

    @NotNull(message = "描述不能为空")
    private String description;
}
