package com.demo.travel.config;

import com.demo.travel.exception.TravelException;
import com.demo.travel.util.ResponseData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * <p>
 *  全局异常处理器
 * </p>
 */
@Slf4j
@RestControllerAdvice
public class WebExceptionAdvice {
    // 处理 RuntimeException 异常
    @ExceptionHandler(TravelException.class)
    public ResponseData<Object> handleRuntimeException(RuntimeException e){
        log.error(e.toString(), e);
        return ResponseData.error("服务器异常");
    }
}
