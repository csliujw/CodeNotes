DROP database IF EXISTS `travel`;

create database travel;
use travel;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for villages
-- ----------------------------
DROP TABLE IF EXISTS `villages`;
CREATE TABLE `villages`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `image_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` tinyint(4) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of villages
-- ----------------------------
INSERT INTO `villages` VALUES (3, '222', 1, NULL, '222', '2024-11-15 11:29:44', '2024-11-15 11:29:44', 0);
INSERT INTO `villages` VALUES (4, '333', 3, NULL, '333', '2024-11-15 11:29:58', '2024-11-15 11:29:58', 0);
INSERT INTO `villages` VALUES (5, '444', 1, NULL, '444', '2024-11-15 11:38:30', '2024-11-15 11:38:30', 0);
INSERT INTO `villages` VALUES (6, '111', 3, NULL, '111', '2024-11-15 14:13:39', '2024-11-15 14:13:39', 0);
INSERT INTO `villages` VALUES (7, 'bbb', 2, NULL, 'aaa', '2024-11-15 14:41:30', '2024-11-15 14:41:30', 0);

SET FOREIGN_KEY_CHECKS = 1;
